# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import ValidationError
from django.http import HttpResponse, HttpResponseRedirect, HttpResponseForbidden
from django.shortcuts import render, redirect

from biblioteca.forms import LoginForm, PessoaFisicaForm
from biblioteca.models import Emprestimo


def index(request):
    if request.user.is_authenticated() and not request.user.groups.filter(name='Usuario'):
        return HttpResponseForbidden('Acesso Negado')

    form = LoginForm(data=request.POST or None)
    if form.is_valid():
        user = form.realizar_autenticacao()
        if user:
            login(request, user)
            return redirect('/')
        else:
            return redirect('/')
    return render(request, 'index.html', locals())

def logoff(request):
    logout(request)
    return redirect('/')

def autenticar(request):
    if request.method == 'GET':
        raise ValidationError('O método não pode ser GET')

    usuario = request.POST.get('usuario')
    senha = request.POST.get('senha')

    user = authenticate(username=usuario, password=senha)
    if user is None:
        raise ValidationError('Usuário não encontrado.')
    else:
        login(request, user)
        return redirect('/')

@login_required(login_url='/')
def emprestimos(request):
    title = 'Meus Empréstimos'
    if request.user.is_authenticated() and not request.user.groups.filter(name='Usuario'):
        return HttpResponseForbidden('Acesso Negado')

    emprestimos = Emprestimo.ativos.filter(usuario__username=request.user.username)
    return render(request, 'emprestimos.html', locals())

@login_required(login_url='/')
@permission_required('biblioteca.add_pessoafisica', login_url='/', raise_exception=True)
def cadastrar_pessoa_fisica(request):
    form = PessoaFisicaForm(data=request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('/')
    return render(request, 'cadastrar_pessoa_fisica.html', locals())




# def somar2(request):
#     try:
#         a = int(request.GET.get('a', 0))
#         b = int(request.GET.get('b', 0))
#         resultado = a + b
#     except ValueError:
#         raise Exception('Informe dois valores inteiros.')
#
#     return render(request, 'calculadora.html', locals())
#
#
# def somar(request, a, b):
#     print dir(request)
#     resultado = int(a) + int(b)
#     return render(request, 'calculadora.html', locals())
#
#
# def hello_world(request):
#     emprestimos = Emprestimo.ativos.all()
#     return render(request, 'hello_world.html', locals())
